""" NumPy ."""

import numpy as np

t0 = 0
tt = 100

t = np.linspace(t0,tt)

t